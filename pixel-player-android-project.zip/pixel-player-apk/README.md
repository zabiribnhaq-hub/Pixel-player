# Pixel Player (Android)

The player is a single web page (`www/index.html`) wrapped as an Android app with Capacitor.

## Easiest: build the APK on GitHub (no installs)
1. Create a new GitHub repository and upload everything in this folder, keeping the `.github` folder.
2. Open the repository's **Actions** tab, pick **Build APK**, and press **Run workflow** (it also runs on every push to `main`).
3. When the run finishes, open it and download the **pixel-player-apk** file at the bottom. Unzip it to get `app-debug.apk`.
4. Copy the APK to your phone, open it, and allow "install unknown apps" when Android asks.

## Or build on your computer
Needs Node 20+, Java 17 and Android Studio (for the Android SDK).
```
npm install
npx cap add android
npm run apk
```
The APK is written to `android/app/build/outputs/apk/debug/app-debug.apk`.

## Notes
- This is a debug-signed APK, fine for installing on your own phone. A Play Store release needs your own signing key.
- The pixel fonts load from Google Fonts, so the first launch needs internet. Without it the app uses a plain monospace font.
- YouTube Music links play through the YouTube embedded player and need internet.
